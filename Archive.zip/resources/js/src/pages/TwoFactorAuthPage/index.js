import TwoFactorAuth from "./TwoFactorAuth";

export default TwoFactorAuth;
