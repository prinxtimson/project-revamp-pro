<script type="text/javascript">
(function() {
  let height = 878
  let width = 496
  let top = window.innerHeight - height;
  let left = window.innerWidth - width;

  window.open('/live-support', '_blank',
    `width=${width},height=${height},toolbar=0,menubar=0,location=0,status=0,scrollbars=1,resizable=0,left=${left},top=${top}`
  );

  return false;
})();
</script>